--*************************************PolicyDocs
SET STATISTICS IO ON
SET STATISTICS TIME ON

DECLARE @PolNumber nvarchar(255),@PolNumber5 nvarchar(255),
    @PolType varchar(255), @DocName nvarchar(255),@Submitted int,@EffDate date, @message_T nvarchar(max);
set @message_T='';set @PolNumber5=''
DECLARE vendor_cursor CURSOR FOR 
SELECT 
   [PolNumber],[PolType],[Effective Date],[DocName],[Submitted]    
  FROM [DevConf].[dbo].[PolicyDocs]
  order by [PolNumber],RecKey;
OPEN vendor_cursor
FETCH NEXT FROM vendor_cursor 
INTO @PolNumber, @PolType, @EffDate, @DocName, @Submitted 
WHILE @@FETCH_STATUS = 0
BEGIN    
    if @PolNumber5 <> @PolNumber 
      set @message_T = @message_T + CHAR(13) + @PolNumber +' | '+ @PolType +' | ' + 
	CONVERT(VARCHAR,@EffDate) +' | '+@DocName+' (' +CONVERT(VARCHAR,ISNULL(@Submitted,''))+') | '
    else if @PolNumber5 = @PolNumber
      set @message_T = @message_T + @DocName+' (' +CONVERT(VARCHAR,ISNULL(@Submitted,''))+') | '
    set @PolNumber5=@PolNumber
    FETCH NEXT FROM vendor_cursor 
    INTO @PolNumber, @PolType, @EffDate, @DocName, @Submitted
END 
if @@FETCH_STATUS <> 0
print @message_T
CLOSE vendor_cursor;
DEALLOCATE vendor_cursor;
----*************************************PolicyDocsMore
--SET STATISTICS IO ON
--SET STATISTICS TIME ON

--DECLARE @PolNumber nvarchar(255),@PolNumber5 nvarchar(255),
--    @PolType varchar(255), @DocName nvarchar(255),@Submitted int,@EffDate date, @message_T nvarchar(max);
--set @message_T='';set @PolNumber5=''
--DECLARE vendor_cursor CURSOR FOR 
--SELECT 
--   [PolNumber],[PolType],[Effective Date],[DocName],[Submitted]    
--  FROM [DevConf].[dbo].[PolicyDocsMore]
--  order by [PolNumber],RecKey;
--OPEN vendor_cursor
--FETCH NEXT FROM vendor_cursor 
--INTO @PolNumber, @PolType, @EffDate, @DocName, @Submitted 
--WHILE @@FETCH_STATUS = 0
--BEGIN    
--    if @PolNumber5 <> @PolNumber 
--      set @message_T = @message_T + CHAR(13) + @PolNumber +' | '+ @PolType +' | ' + 
--	CONVERT(VARCHAR,@EffDate) +' | '+@DocName+' (' +CONVERT(VARCHAR,ISNULL(@Submitted,''))+') | '
--    else if @PolNumber5 = @PolNumber
--      set @message_T = @message_T + @DocName+' (' +CONVERT(VARCHAR,ISNULL(@Submitted,''))+') | '
--    set @PolNumber5=@PolNumber
--    FETCH NEXT FROM vendor_cursor 
--    INTO @PolNumber, @PolType, @EffDate, @DocName, @Submitted
--END 
--if @@FETCH_STATUS <> 0
--print @message_T
--CLOSE vendor_cursor;
--DEALLOCATE vendor_cursor;
