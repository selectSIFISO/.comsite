--*************************************PolicyDocs
SET STATISTICS IO ON
SET STATISTICS TIME ON

SELECT *
FROM
(
  SELECT  
   [PolNumber]
    ,[PolType]
    ,[Effective Date]
    ,[DocName]
    ,[Submitted]    
  FROM [DevConf].[dbo].[PolicyDocs]  
) AS SourceTable
PIVOT
(
  AVG([Submitted]
)
FOR [DocName] IN ([Doc A],[Doc B],[Doc C],[Doc D],[Doc E])
) AS PivotTable;
--*************************************PolicyDocsMore
--SET STATISTICS IO ON
--SET STATISTICS TIME ON

--SELECT *
--FROM
--(
--  SELECT  
--   [PolNumber]
--    ,[PolType]
--    ,[Effective Date]
--    ,[DocName]
--    ,[Submitted]    
--  FROM [DevConf].[dbo].[PolicyDocsMore]  
--) AS SourceTable
--PIVOT
--(
--  AVG([Submitted]
--)
--FOR [DocName] IN ([Doc A],[Doc B],[Doc C],[Doc D],[Doc E])
--) AS PivotTable;
