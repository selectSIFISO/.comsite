--*************************************PolicyDocs
SET STATISTICS IO ON
SET STATISTICS TIME ON

DECLARE @columns NVARCHAR(MAX), @sql NVARCHAR(MAX);
SET @columns = N'';
SELECT @columns += N', p.' + QUOTENAME(Name) 
  FROM (SELECT [DocName] Name FROM [DevConf].[dbo].[PolicyDocs] AS p  
  GROUP BY [DocName]) AS x;
SET @sql = N'
SELECT [PolNumber], ' + STUFF(@columns, 1, 2, '') + '
FROM
(select [PolNumber], [Submitted] Quantity, [DocName] Name
   from [DevConf].[dbo].[PolicyDocs]
) AS j
PIVOT
(SUM(Quantity) FOR Name IN ('
  + STUFF(REPLACE(@columns, ', p.[', ',['), 1, 1, '')
  + ')) AS p;';
EXEC sp_executesql @sql;
--*************************************PolicyDocsMore
--SET STATISTICS IO ON
--SET STATISTICS TIME ON

--DECLARE @columns NVARCHAR(MAX), @sql NVARCHAR(MAX);
--SET @columns = N'';
--SELECT @columns += N', p.' + QUOTENAME(Name) 
--  FROM (SELECT [DocName] Name FROM [DevConf].[dbo].[PolicyDocsMore] AS p  
--  GROUP BY [DocName]) AS x;
--SET @sql = N'
--SELECT [PolNumber], ' + STUFF(@columns, 1, 2, '') + '
--FROM
--(select [PolNumber], [Submitted] Quantity, [DocName] Name
--   from [DevConf].[dbo].[PolicyDocsMore]
--) AS j
--PIVOT
--(SUM(Quantity) FOR Name IN ('
--  + STUFF(REPLACE(@columns, ', p.[', ',['), 1, 1, '')
--  + ')) AS p;';
--EXEC sp_executesql @sql;
