--*************************************PolicyDocs
SET STATISTICS IO ON
SET STATISTICS TIME ON
DECLARE @cols AS NVARCHAR(MAX), @query  AS NVARCHAR(MAX);

SET @cols = STUFF((SELECT distinct ',' + QUOTENAME(c.[DocName]) 
            FROM [DevConf].[dbo].[PolicyDocs] c
            FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)') 
        ,1,1,'')

set @query = 'SELECT [PolNumber], ' + @cols + ' from (
                select [PolNumber], [Submitted] amount , [DocName] category
                from [DevConf].[dbo].[PolicyDocs]
           ) x  pivot (max(amount) for category in (' + @cols + ')) p '
execute(@query)
--*************************************PolicyDocsMore
--SET STATISTICS IO ON
--SET STATISTICS TIME ON
--DECLARE @cols AS NVARCHAR(MAX), @query  AS NVARCHAR(MAX);

--SET @cols = STUFF((SELECT distinct ',' + QUOTENAME(c.[DocName]) 
--            FROM [DevConf].[dbo].[PolicyDocsMore] c
--            FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)') 
--        ,1,1,'')

--set @query = 'SELECT [PolNumber], ' + @cols + ' from (
--                select [PolNumber], [Submitted] amount , [DocName] category
--                from [DevConf].[dbo].[PolicyDocsMore]
--           ) x  pivot (max(amount) for category in (' + @cols + ')) p '
--execute(@query)
