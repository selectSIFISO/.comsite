#!/bin/sh
# $Id: cron-curl.sh,v 1.1.2.1 2005/08/17 20:03:29 dries Exp $

curl --silent --compressed http://yoursite.com/cron.php
