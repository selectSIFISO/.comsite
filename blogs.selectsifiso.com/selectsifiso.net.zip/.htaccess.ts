# BEGIN iThemes Security - Do not modify or remove this line
# iThemes Security Config Details: 2
	# Enable HackRepair.com's blacklist feature - Security > Settings > Banned Users > Default Blacklist
	# Start HackRepair.com Blacklist
	
	# Start Abuse Agent Blocking
	
	# End HackRepair.com Blacklist, http://pastebin.com/u/hackrepair

	# Protect System Files - Security > Settings > System Tweaks > System Files

	# Disable Directory Browsing - Security > Settings > System Tweaks > Directory Browsing



		# Disable PHP in Uploads - Security > Settings > System Tweaks > Uploads

		# Filter Suspicious Query Strings in the URL - Security > Settings > System Tweaks > Suspicious Query Strings

# END iThemes Security - Do not modify or remove this line

# BEGIN WordPress

# END WordPress
