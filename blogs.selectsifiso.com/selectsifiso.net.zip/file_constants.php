<?php
$host="localhost";
$user="root";
$pass="thulabo11";
$db="shashaz_db";
?>