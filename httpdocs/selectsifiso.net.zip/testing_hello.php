<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
  <title>Eshashalazini - Celebrating South African Music</title>  
  <!--<link rel="stylesheet" href="css/body_layer_style.css" type="text/css" />
  <link rel="stylesheet" href="css/Cstyle.css" type="text/css" />
  <link rel="stylesheet" href="css/style.css" type="text/css" />
  <link rel="stylesheet" href="css/styles.css" type="text/css" />  
  <script type="text/javascript" src="js/jquery-1.3.1.min.js"></script>
  <script type="text/javascript" src="js/gallery.js"></script>
  <script type="text/javascript" src="js/jquery.js"></script>
  <script type="text/javascript" src="js/jquery.cookie.js"></script>
  <meta http-equiv="content-type" content="text/html; charset=utf-8" /> -->
 </head>
 <body style="background: url(images/background_11.png) repeat-x #e6e3dc;margin: 0;font-family:Verdana, Geneva, sans-serif;
 padding:0;width:100%;"> 
        <!--id=wrapper-->
 <div style="width: 900px;margin: 0 auto; border: solid 1px red; ">
        <!--id=LOGO-->
    <!--<div id="header">-->
        <!--id=header
        <div style="background: url(images/logo4.png) no-repeat; width: 380px; height: 73px; margin-left: 7px;">-->
        <div style="background: url(images/logo4.png) no-repeat; width: 380px; height: 73px; margin-left: 0px;">
         </div>
        <!--id=updates-->
         <!--<div id="updates" style="background: url(images/updates.png) repeat-x #e6e3dc;">
            <div style="margin-top:-19pt; width:600px">
                <form action="#">                    
                    <select style="width:100px; border: solid thin #859c0a;" name="degree">
                    <option>lyrics</option>
                    <option>artist</option>
                    <option>album</option>
                    </select>
                    <input title="username" name="username" style="background: url(images/formfield3.png) transparent no-repeat;" class="username" value="search ..." onclick="if ( value == 'search ...' ) { value = ''; }"/>  
                    <input type="submit" name="Login" class="submit" value="search" tabindex="3" />                                        
                </form>
            </div>            
        </div>
        
        <div id="login" style="background: url(images/loginbg.png);">
        <div id="loginwelcome">Welcome </div>        
            <form action="#">
                <p>
                <input title="username" name="username" style="background: url(images/formfield.png) transparent no-repeat;" class="username" value="Username" onclick="if ( value == 'Username' ) { value = ''; }"/>
                <input name="password" type="password" style="background: url(images/formfield.png) transparent no-repeat;" class="password" title="password" value="Password" onclick="if ( value == 'Password' ) { value = ''; }"/>
                <input type="submit" name="Login" class="submit" value="login" tabindex="3" />                
                </p>
            </form>
        </div>
             -->
 </div> 
 </body>
</html> 