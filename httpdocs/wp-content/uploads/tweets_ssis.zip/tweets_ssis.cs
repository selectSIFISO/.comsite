/* Microsoft SQL Server Integration Services Script Component
*  Write scripts using Microsoft Visual C# 2008.
*  ScriptMain is the entry point class of the script.*/

using System;
using System.Data;
using Microsoft.SqlServer.Dts.Pipeline.Wrapper;
using Microsoft.SqlServer.Dts.Runtime.Wrapper;
using System.Xml;
using System.ServiceModel.Syndication;

[Microsoft.SqlServer.Dts.Pipeline.SSISScriptComponentEntryPointAttribute]
public class ScriptMain : UserComponent
{
    private SyndicationFeed sS_Tweets = null;
    private XmlReader sS_XmlReader = null;
    public override void PreExecute()
    {
        base.PreExecute();
        sS_XmlReader = XmlReader.Create(Connections.Connection.ConnectionString);
        sS_Tweets = SyndicationFeed.Load(sS_XmlReader);
        /*
          Add your code here for preprocessing or remove if not needed
        */
    }

    public override void PostExecute()
    {
        base.PostExecute();
        /*
          Add your code here for postprocessing or remove if not needed
          You can set read/write variables here, for example:
          Variables.MyIntVar = 100
        */
    }

    public override void CreateNewOutputRows()
    {
        if (sS_Tweets != null)
        {
            foreach (var item in sS_Tweets.Items)
            {
                Output0Buffer.AddRow();
                Output0Buffer.sSTweets = item.Title.Text;
                Output0Buffer.sSTwitterDate = item.PublishDate.ToString();
            }
            Output0Buffer.SetEndOfRowset();
        }
        /*
          Add rows by calling the AddRow method on the member variable named "<Output Name>Buffer".
          For example, call MyOutputBuffer.AddRow() if your output was named "MyOutput".
        */
    }

}
